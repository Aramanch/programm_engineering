from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.utils import executor
from aiogram.types import ContentType, Message

TOKEN = '5848603840:AAGaK_8hHlB0EdvGWmcopw0PNCOQsg9TUG8'

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)


@dp.message_handler(commands=['start'])
async def begin(message: types.Message):
    await bot.send_message(message.chat.id, "Приветствую!")

@dp.message_handler(commands=['photo'])
async def cats(message: types.Message):
    with open('/home/aram/PycharmProjects/LosThings_bot/passport.jpg', 'rb') as photo:
        '''
        # Old fashioned way:
        await bot.send_photo(
            message.chat.id,
            photo,
            caption='Cats are here 😺',
            reply_to_message_id=message.message_id,
        )
        '''

        await message.reply_photo(photo, caption='Найден: ауд.326/ Пт 25.11 12.00 \n Текущее местоположение: КПП')

executor.start_polling(dp)
